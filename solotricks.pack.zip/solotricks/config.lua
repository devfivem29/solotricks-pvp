Config = {}

Config.Locale = 'en'  -- 'en' for English, 'fr' for French

