fx_version 'adamant'
game 'gta5'
lua54 'yes'
description "solotricks"
version "1.9.4"

client_scripts {
    'config.lua',
    'locales.lua',
 'client.lua'
}
dependency '/assetpacks'